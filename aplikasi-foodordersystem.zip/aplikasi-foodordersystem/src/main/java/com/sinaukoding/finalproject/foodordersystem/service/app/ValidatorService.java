package com.sinaukoding.finalproject.foodordersystem.service.app;

public interface ValidatorService {

    void validator(Object data);

}
