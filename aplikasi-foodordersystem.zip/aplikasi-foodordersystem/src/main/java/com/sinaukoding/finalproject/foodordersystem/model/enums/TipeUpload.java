package com.sinaukoding.finalproject.foodordersystem.model.enums;

public enum TipeUpload {

    PRODUK

}
